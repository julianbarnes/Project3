#!/bin/bash

PORT=$1

python project.py $1
